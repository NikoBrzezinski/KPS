t=[-5:0.01:5]
amp = 2;
freq = 0.5;
faza = 0;
x=amp*sin(2*freq*pi*t+faza);
plot(t,x)
grid on;
axis ([-5 5 -amp*2 amp*2])
ylabel('x(t)')
xlabel('Time(s)')
title('sin')
