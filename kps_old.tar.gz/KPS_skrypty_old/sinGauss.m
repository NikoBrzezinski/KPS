t=[-5:0.01:5]
amp = 2;
freq = 0.5;
faza = 0;
men = 0;
sigma = 1;
y=amp*exp(-((t-men).^2)/(2*sigma^2));
x=amp*sin(2*freq*pi*t+faza);
z=x.*y;

plot(t,z)
grid on;
axis ([-5 5 -amp*2 amp*2])
ylabel('x(t)')
xlabel('Time(s)')
title('sin*gauss')
