t=[-5:0.01:5]
amp = 2;
freq = 0.5;
faza = 2;
skalar =2;
x=amp*sin((freq*pi*t)-pi/faza);
y=x*skalar;
plot(t,x)
plot(t,y);
grid on;
axis ([-5 5 -amp amp])
ylabel('x(t)')
xlabel('Time(s)')
title('sinusoida')
