t=[-5:0.01:5]
freq = 1;
amp = 1;
x=(2*amp/pi)*asin(sin(2*pi*freq*t));
plot(t,x)
grid on;
axis ([-5 5 -amp amp])
ylabel('x(t)')
xlabel('Time(s)')
title('trojkot')
