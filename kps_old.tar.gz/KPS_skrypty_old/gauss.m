t=[-5:0.01:5]
men = 0;
amp = 2;
sigma = 1;
x=amp*exp(-((t-men).^2)/(2*sigma^2));
plot(t,x)
grid on;
axis ([-5 5 -0.5 amp])
ylabel('x(t)')
xlabel('Time(s)')
title('gauss')
