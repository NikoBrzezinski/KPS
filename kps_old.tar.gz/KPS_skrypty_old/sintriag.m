t=[-5:0.01:5]
freq = 1;
amp = 1;
x=(2*amp/pi)*asin(sin(2*pi*freq*t));
y=amp*sin(2*freq*pi*t+faza);
z=x.*y;

plot(t,z)
grid on;
axis ([-5 5 -0.5 amp+0.5])
ylabel('x(t)')
xlabel('Time(s)')
title('sin.*triangle')
